# Certificate Generator (template-based)

Static, client-side participant certificate generator.

Features
- Two built-in CSS certificate templates
- Live preview while editing participant name, event title, date, organizer
- Upload logo and signature images
- Export certificate as PNG or PDF (uses html2canvas + jsPDF)
- No backend required — runs in the browser

Usage
1. Place files from this folder into your repository (e.g., `/web/` or repo root).
2. Open `index.html` in a browser.
3. Fill the form, upload optional logo/signature, choose a template, then click "Download PNG" or "Download PDF".

Customization
- Edit styles in `styles.css` to create more templates.
- You can add fonts by linking them in `index.html` and using them in the certificate container.
- For batch generation from CSV, I can add a server-side script (Node) to create PDFs.

Dependencies (CDN)
- html2canvas
- jsPDF (for PDF export)

License
- MIT